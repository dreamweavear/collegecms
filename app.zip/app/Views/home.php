php
<!DOCTYPE html>
<html>
<head>
    <title>मेरी वेबसाइट</title>
</head>
<body>
    <h1>मेरी वेबसाइट में आपका स्वागत है!</h1>
</body>
</html>
