<?php
namespace App\Controllers;
use App\Models\AdmissionModel;
use CodeIgniter\HTTP\Files\UploadedFile;

class Admission extends BaseController
{
    public function index()
    {
       echo " admission Controller working" ;
    }

 }